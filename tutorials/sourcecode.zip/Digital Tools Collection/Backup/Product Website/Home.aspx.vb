﻿Public Class Home
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Unnamed1_Click(sender As Object, e As EventArgs)
        If Checkbox1.Checked = False And Checkbox2.Checked = False And Checkbox3.Checked = False Then
            MsgBox("Please select at least one product!")
        Else
            Response.Redirect("/OrderComplete.aspx?a=" & Checkbox1.Checked & "&b=" & Checkbox2.Checked & "&c=" & Checkbox3.Checked & "&d=" & Checkbox4.Checked)
        End If
    End Sub
End Class