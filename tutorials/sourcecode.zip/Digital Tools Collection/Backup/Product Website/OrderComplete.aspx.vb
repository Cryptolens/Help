﻿Public Class OrderComplete
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'Please note that it would be much safer to store the license configuration as a binary number
        'EX: if we have 3 features, than we can do as following:
        '
        ' option1 = 2^2
        ' option2 = 2^1
        ' option3 = 2^0
        '
        ' hence if we would order option 1 and 3, we would get: 2^2 + 2^0 = "5".
        ' 
        ' if you would rather want to implement this way using binary numbers,
        ' please create a new discussion at! :)
        '  http://skgl.codeplex.com/discussions/topics/5452/help-support

        Dim option1 As Boolean = Request("a")
        Dim option2 As Boolean = Request("b")
        Dim option3 As Boolean = Request("c")
        Dim option4 As Boolean = Request("d")

        'Now we are going to be working with SKGL API
        ' Documentation at: http://skgl.codeplex.com/documentation

        Dim skc As New SKGL.SerialKeyConfiguration
        Dim KeyGenerator As New SKGL.Generate(skc)

        ' First, assign a key the features.
        skc.Features(1) = option1
        skc.Features(2) = option2
        skc.Features(3) = option3
        skc.Features(4) = option4

        ' Secondly, the secret phase
        KeyGenerator.secretPhase = "dtcKeepThisSafe123$"

        ' Now, we can generate a key.
        Label1.Text = KeyGenerator.doKey(365)




    End Sub

End Class